package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoccerShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoccerShopApplication.class, args);
	}

}
